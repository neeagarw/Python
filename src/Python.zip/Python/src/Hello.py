print("Hello World")
print("My first Program")
